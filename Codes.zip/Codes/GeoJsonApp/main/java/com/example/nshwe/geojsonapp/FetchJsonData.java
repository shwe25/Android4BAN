package com.example.nshwe.geojsonapp;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by nshwe on 08-05-2018.
 */

class FetchJsonData extends AsyncTask{
    private String location;
    private TextView textView;
    private String result = "",data = "";
    public FetchJsonData(String location, TextView textView) {
        this.location = location;
        this.textView = textView;
    }

    @Override
    protected Object doInBackground(Object[] objects) {
        String urlID = "http://maps.googleapis.com/maps/api/geocode/json?address="+location;
        Log.d("URL",urlID);
        try {
            URL url = new URL(urlID);
            HttpURLConnection httpsURLConnection = (HttpURLConnection) url.openConnection();
            Log.d("http","");
            InputStream inputStream = httpsURLConnection.getInputStream();
            Log.d("input Stream","");
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            Log.d("Buffer Reader","");
            String line = "";
            while (line != null){
                line = bufferedReader.readLine();
                result += line;
            }
            Log.d("Result", result);
            JSONObject object = new JSONObject(result);
            String status = object.getString("status");
            String address = object.getJSONArray("results").getJSONObject(0)
                    .getString("formatted_address");
            Log.d("URL", urlID);
            Log.d("Result", result);
            data = "Status : "+status+"\nAddress : "+address;
        } catch (Exception e) {
            e.printStackTrace();
            try {
                JSONObject object = new JSONObject(result);
                String error_message = object.getString("error_message");
                String status = object.getString("status");
                data = "Status : "+status+"\nError Response : "+error_message;
            } catch (JSONException e1) {
                e1.printStackTrace();
            }
        }
        return null;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
        textView.setText(data);
    }
}
