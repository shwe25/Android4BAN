package com.example.nshwe.geojsonapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private SearchView searchView;
    private Button fetch;
    private TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchView = findViewById(R.id.searchview);
        fetch = findViewById(R.id.fetch);
        textView = findViewById(R.id.textView);

        fetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fetchData();
            }
        });
    }

    private void fetchData() {
        Log.d("Button","Clicked");
        String location = searchView.getQuery().toString();
        FetchJsonData fetchJsonData = new FetchJsonData(location,textView);
        fetchJsonData.execute();
    }
}
