package com.example.nshwe.filehandling;

import android.app.AlertDialog;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class DiffMemoriesActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText editText;
    private Button in_cache,ex_cache,ex_private,ex_public;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diff_memories);

        Log.d("onCreate","executing");
        editText = findViewById(R.id.write_et);
        in_cache = findViewById(R.id.internal_cache);
        ex_cache = findViewById(R.id.external_cache);
        ex_private = findViewById(R.id.external_private);
        ex_public = findViewById(R.id.external_public);

        in_cache.setOnClickListener(this);
        ex_cache.setOnClickListener(this);
        ex_private.setOnClickListener(this);
        ex_public.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.internal_cache :
                savetoInternalCache();
                break;
            case R.id.external_cache :
                savetoExternalCache();
                break;
            case R.id.external_private :
                savetoExternalPrivate();
                break;
            case R.id.external_public :
                savetoExternalPublic();
                break;
        }
    }

    private void savetoExternalCache() {
        Log.d("savetoExternalCache","executing");
        File path = getExternalCacheDir();
        File file = new File(path,"MyText1.txt");
        saveData(file);
    }

    private void savetoInternalCache() {
        Log.d("savetoInternalCache","executing");
        File path = getCacheDir();
        File file = new File(path,"MyText2.txt");
        saveData(file);
    }

    private void savetoExternalPrivate() {
        Log.d("savetoExternalPrivate","executing");
        File path = getExternalFilesDir("MyData");
        File file = new File(path,"MyText3.txt");
        saveData(file);
    }

    private void savetoExternalPublic() {
        Log.d("savetoExternalPublic","executing");
        File path = Environment.getExternalStorageDirectory();
        File file = new File(path,"MyText4.txt");
        saveData(file);
    }

    private void saveData(File file){
        Log.d("saveData","executing");
        try(FileOutputStream fileOutputStream = new FileOutputStream(file);
            OutputStreamWriter streamWriter = new OutputStreamWriter(fileOutputStream)) {

            streamWriter.write(editText.getText().toString());
            streamWriter.flush();
            display("Data saved in "+file);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void display(String s) {
        Log.d("display","executing");
        new AlertDialog.Builder(this)
                .setCancelable(true)
                .setMessage(s)
                .show();

    }
}
