package com.example.nshwe.filehandling;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class FileWriteActivity extends AppCompatActivity {

    private EditText editText;
    private Button button,read_activity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_write);

        editText = findViewById(R.id.fileWrite_et);
        button = findViewById(R.id.write_btn);
        read_activity = findViewById(R.id.read_activity);

        read_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getBaseContext(),FileReadActivity.class));
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                writeData();
            }
        });
    }

    private void writeData() {
        FileOutputStream fileOutputStream = null;
        OutputStreamWriter streamWriter = null;
        try {
            fileOutputStream = openFileOutput
                    ("MyData.txt", Context.MODE_APPEND);
            streamWriter = new OutputStreamWriter(fileOutputStream);

            File folder = getFilesDir();

            streamWriter.write(editText.getText().toString());
            streamWriter.flush();

            Log.d("Files Directory",folder.toString());
            Toast.makeText(this,"Data saved Successfully " +
                    "into the path "+folder,Toast.LENGTH_LONG).show();;
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try {
                if(streamWriter != null)
                    streamWriter.close();
                if(fileOutputStream != null)
                    fileOutputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
    }
}
