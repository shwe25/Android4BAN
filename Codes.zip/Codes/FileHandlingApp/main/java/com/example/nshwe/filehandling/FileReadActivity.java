package com.example.nshwe.filehandling;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;

public class FileReadActivity extends AppCompatActivity {

    private EditText editText;
    private Button button,diff_Mem_activity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_read);

        editText = findViewById(R.id.fileRead_et);
        button = findViewById(R.id.read_btn);
        diff_Mem_activity = findViewById(R.id.diff_mem_btn);

        diff_Mem_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getBaseContext(),DiffMemoriesActivity.class));
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                readData();
            }
        });
    }
    private void readData() {
        try(FileInputStream fileInputStream = openFileInput("MyData.txt");
            InputStreamReader streamReader = new InputStreamReader(fileInputStream)){

            char[] ch = new char[100];
            String data = "";
            int readChar = 0;

            while ((readChar = streamReader.read(ch))> 0){
                data += String.copyValueOf(ch,0,readChar);
            }
            editText.setText(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
