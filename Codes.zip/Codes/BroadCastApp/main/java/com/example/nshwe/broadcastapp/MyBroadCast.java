package com.example.nshwe.broadcastapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by nshwe on 23-04-2018.
 */

public class MyBroadCast extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("onReceive()",intent.getAction());
        Toast.makeText(context,intent.getAction(),Toast.LENGTH_LONG).show();
    }
}
