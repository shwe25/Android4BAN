package com.example.nshwe.msgservice;

import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;


/**
 * Created by nshwe on 20-04-2018.
 */

public class NotificationActivity extends AppCompatActivity{

    TextView textView;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        textView = findViewById(R.id.text);

        textView.setText(getIntent().getStringExtra("MyKey"));
    }
}
