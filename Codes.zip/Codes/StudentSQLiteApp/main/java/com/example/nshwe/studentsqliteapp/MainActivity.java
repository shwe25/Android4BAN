package com.example.nshwe.studentsqliteapp;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private EditText sId,sName,sMarks;
    private Button add,view,update,delete,viewAll;
    private SQLiteDatabase database;

    private final String TABLE_NAME = "student_table";
    private final String COL_ID = "id";
    private final String COL_NAME = "name";
    private final String COL_MARKS = "marks";
    private final String DB_NAME = "Stud_DB";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sId = findViewById(R.id.stud_id);
        sName = findViewById(R.id.stud_name);
        sMarks = findViewById(R.id.stud_marks);
        add = findViewById(R.id.add_button);
        view = findViewById(R.id.view_button);
        update = findViewById(R.id.update_button);
        delete = findViewById(R.id.delete_button);
        viewAll = findViewById(R.id.viewAll_button);

        database = openOrCreateDatabase(DB_NAME, Context.MODE_PRIVATE,null);
        database.execSQL("create table if not exists "+TABLE_NAME+
                "("+COL_ID+" varchar,"+COL_NAME+" varchar,"+COL_MARKS+" varchar)");
        File file = getDatabasePath(DB_NAME);
        Log.d("DB Path",file.toString());

    }

    public void add(View v){

        if(sId.getText().toString().trim().length() == 0 ||
            sName.getText().toString().trim().length() == 0 ||
            sMarks.getText().toString().trim().length() == 0 )
                display("Error","All fields are mandatory...!");
        else {
            ContentValues values = new ContentValues();
            values.put(COL_ID, sId.getText().toString());
            values.put("name", sName.getText().toString());
            values.put("marks", sId.getText().toString());
            long i = database.insert(TABLE_NAME, null, values);
            if(i > 0) {
                display("Success", "1 row insterted");
                clearFields();
            }
            else
                display("Error","Error while inserting");
        }
    }

    public void view(View v){
        if (sId.getText().toString().trim().length() == 0)
            display("Error","Id is mandatory");
        else {
            String where = " WHERE "+COL_ID+"="+sId.getText().toString();
            Cursor cursor = database.rawQuery("select * from " + TABLE_NAME+where,null);
            StringBuilder builder = new StringBuilder("Student Records");
            if (cursor.moveToNext()) {
                builder.append("\n------------------");
                builder.append("\nID : " + cursor.getString(0));
                builder.append("\nNAME : " + cursor.getString(1));
                builder.append("\nMARKS : " + cursor.getString(2));
            }
            if (builder.toString().equals("Student Records"))
                display("Success", "No Records found...");
            else
                display("Success", builder.toString());
        }
    }
    public void delete(View v){
        if (sId.getText().toString().trim().length() == 0)
            display("Error","Id is mandatory");
        else {
            String where = COL_ID+"="+sId.getText().toString();
            int i = database.delete(TABLE_NAME, where,null);
            if(i > 0)
                display("Success","Row deleted");
            else
                display("Success","No row deleted");
        }
    }
    public void update(View v) {

        if (sId.getText().toString().trim().length() == 0 ||
                sName.getText().toString().trim().length() == 0 ||
                sMarks.getText().toString().trim().length() == 0)
            display("Error", "All fields are mandatory...!");
        else {
            ContentValues values = new ContentValues();
            values.put(COL_NAME, sName.getText().toString());
            values.put(COL_MARKS, sMarks.getText().toString());
            String where = COL_ID + "=" + sId.getText().toString();
            int i = database.update(TABLE_NAME, values, where, null);
            if (i > 0) {
                display("Success", "Row Updated");
                clearFields();
            }
            else
                display("Success", "No rows updated");
        }
    }
    public void viewAll(View v){

        Cursor cursor = database.rawQuery("select * from "+TABLE_NAME,null);
        StringBuilder builder = new StringBuilder("Student Records");
        while (cursor.moveToNext()){
            builder.append("\n------------------");
            builder.append("\nID : "+cursor.getString(0));
            builder.append("\nNAME : "+cursor.getString(1));
            builder.append("\nMARKS : "+cursor.getString(2));
        }
        if(builder.toString().equals("Student Records"))
            display("Success","No Records found...");
        else
            display("Success",builder.toString());
    }

    private void display(String status, String msg) {

        new AlertDialog.Builder(this)
                .setTitle(status)
                .setMessage(msg)
                .setCancelable(true)
                .show();
    }


    private void clearFields() {
        sId.setText("");
        sName.setText("");
        sMarks.setText("");
    }

}
