package com.example.nshwe.mythreadapplication;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class ThreadActivity extends AppCompatActivity {

    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thread);

        textView = findViewById(R.id.text);
        System.out.println("On Create = "+Thread.currentThread().getName());
    }

    @Override
    protected void onResume() {
        super.onResume();
        textView.setText(Thread.currentThread().getName());
        myThread();
    }

    private void myHandler(Runnable r) {
        Handler handler = new Handler();
        handler.post(r);
    }

    private void myThread() {
        Runnable r = () -> {
            System.out.println("My Thread = "+Thread.currentThread().getName());
            /*Toast.makeText(this,"My Thread = "
                    +Thread.currentThread().getName(),Toast.LENGTH_LONG).show();*/
            for(int i = 1;i <= 5;i++) {
                textView.setText(i+"");
                Log.d("MyThread ", " "+i);
                try {
                    Thread.sleep( 1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            //textView.setText(Thread.currentThread().getName());
            Log.d("MyThread",Thread.currentThread().getName());
        };
        myHandler(r);
       /* Thread t = new Thread(r,"FirstThread");
        t.start();*/
    }
}
