package com.example.nshwe.mythreadapplication;

import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
/**
 * Created by nshwe on 16-04-2018.
 */
public class MyAsyncTask extends AsyncTask {

    TextView textView;
    Button button;
    ProgressBar progressBar;

    public MyAsyncTask(TextView textView, Button button, ProgressBar progressBar) {
        this.textView = textView;
        this.button = button;
        this.progressBar = progressBar;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        Log.d("onPreExecute",Thread.currentThread().getName());
        button.setEnabled(false);
        textView.setText("Download is abt to start...");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    protected Object doInBackground(Object[] objects) {
        Log.d("doInBackground",Thread.currentThread().getName());
        for (int i = 1;i<=100 ; i++){
            try {
                publishProgress(i);
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Object[] values) {
        super.onProgressUpdate(values);
        Log.d("onProgressUpdate",Thread.currentThread().getName());
        textView.setText("Downloaded "+values[0]+"% ...");
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
        Log.d("onPostExecute",Thread.currentThread().getName());
        progressBar.setVisibility(View.GONE);
        textView.setText("Downloading complete");
        button.setEnabled(true);
    }
}
