package com.example.nshwe.mythreadapplication;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class AsyncActivity extends AppCompatActivity {

    ProgressBar progressBar;
    TextView textView;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_async);

        Log.d("onCreate",Thread.currentThread().getName());

        progressBar = findViewById(R.id.progress_bar);
        textView = findViewById(R.id.textview);
        button = findViewById(R.id.download);

        button.setOnClickListener((view) -> {

            MyAsyncTask myAsyncTask = new MyAsyncTask(textView,button,progressBar);
            myAsyncTask.execute();

        });
    }
}
