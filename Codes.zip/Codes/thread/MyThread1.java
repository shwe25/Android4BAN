package edu.jsp.thread;

public class MyThread1 implements Runnable{

	@Override
	public void run() {

		System.out.println("Thread1 Name "+Thread.currentThread().getName());
		
		for(int i =11;i<=20; i++){
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(i);
		}
	}

}
