package edu.jsp.thread;

public class Util {

	public static void main(String[] args) {
		System.out.println("Main starts");
		MyThread t1 = new MyThread();
		System.out.println("Main Name "+Thread.currentThread().getName());
		t1.setName("MyName");
		t1.start();
		
		
		MyThread1 t2 = new MyThread1();//Runnable implementation object
		Thread t = new Thread(t2);//Creating thread by passing runnable instance
		t.start();
		System.out.println("Main ends");
	}
}
