package com.example.nshwe.myfirstpplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class LifeCycleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("onCreate","Activity Created");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("onStart","Activity Started");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("onResume","Activity Resumed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("onPause","Activity Paused");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("onStop","Activity Stopped");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("onDestroy","Activity Destroyed");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("onRestart","Activity Restarted");
    }
}
