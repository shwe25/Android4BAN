package com.example.nshwe.uicomponents;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class EditButtonActivity extends AppCompatActivity {

    private TextView my_text;
    private EditText name_et;
    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_button);

        String msg = getIntent().getStringExtra("country");

        my_text = findViewById(R.id.text);
        name_et = findViewById(R.id.name_edit);
        button = findViewById(R.id.my_btn);

        name_et.setText(msg);
        /*View.OnClickListener clickListener = new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),my_text.getText(),Toast.LENGTH_LONG).show();
            }
        };*/
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(EditButtonActivity.this,name_et.getText(),Toast.LENGTH_SHORT).show();

                my_text.setText(name_et.getText());
            }
        });
    }
}
