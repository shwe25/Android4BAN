package com.example.nshwe.uicomponents;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class IntetActivity extends AppCompatActivity implements View.OnClickListener{

    Button editBtn,checkBtn,dateBtn,spinnerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intet);

        editBtn = findViewById(R.id.editText_btn);
        checkBtn = findViewById(R.id.check_radio_btn);
        dateBtn = findViewById(R.id.date_time_btn);
        spinnerBtn = findViewById(R.id.spinner_btn);

        editBtn.setOnClickListener(this);
        checkBtn.setOnClickListener(this);
        dateBtn.setOnClickListener(this);
        spinnerBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.editText_btn :editAction();
                break;
            case R.id.check_radio_btn:checkBoxAction();
                break;
            case R.id.date_time_btn:dateTimeAction();
                break;
            case R.id.spinner_btn:spinnerAction();
                break;

        }
    }

    private void spinnerAction() {
        Intent intent = new Intent(this,SpinnerNAutoCompleteActivity.class);
        startActivity(intent);
    }

    private void dateTimeAction() {
        Intent intent = new Intent(this,DateNTimePickerActivity.class);
        startActivity(intent);
    }

    private void checkBoxAction() {
        Intent intent = new Intent(this,CheckBoxNRadioButtonActivity.class);
        startActivity(intent);
    }

    private void editAction() {
        Intent intent = new Intent(this,EditButtonActivity.class);
        intent.putExtra("myKey","Jspiders BAN");
        startActivity(intent);
    }
}
