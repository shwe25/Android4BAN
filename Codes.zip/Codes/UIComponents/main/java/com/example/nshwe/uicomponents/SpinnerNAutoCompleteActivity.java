package com.example.nshwe.uicomponents;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Spinner;
import android.widget.Toast;

public class SpinnerNAutoCompleteActivity extends AppCompatActivity {

    Button edit_intent_btn;
    AutoCompleteTextView autoCompleteTextView;
    MultiAutoCompleteTextView multiAutoCompleteTextView;
    Spinner spinner;
    String[] country,stream;
    String[] msgs = {"What","when","why","how","where","are","i","u","is","then","fine"};
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spinner_autocomplete);

        edit_intent_btn = findViewById(R.id.edit_btn);
        edit_intent_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setEditIntentAction();
            }
        });


        multiAutoCompleteTextView = findViewById(R.id.multiautoComplete);
        autoCompleteTextView = findViewById(R.id.autoComplete);
        spinner = findViewById(R.id.spinner_country);
        country = getResources().getStringArray(R.array.country);
        stream = getResources().getStringArray(R.array.streams);

        Log.d("country",country[3]);

        setEvent();
        setAutoCompleteAction();
        setMultiAutoCompleteAction();
    }

    private void setEditIntentAction() {
        Intent intent = new Intent(this,EditButtonActivity.class);
        intent.putExtra("country",spinner.getSelectedItem().toString());
        startActivity(intent);
    }

    private void setMultiAutoCompleteAction() {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this,android.R.layout.simple_list_item_1,msgs);
        multiAutoCompleteTextView.setAdapter(adapter);
        multiAutoCompleteTextView.setThreshold(1);
        //Tokenizer is must in multi auto complete view,
        // whithout that u can't able to get any suggessions
        multiAutoCompleteTextView.setTokenizer(new SpaceTokenizer());
    }

    private void setAutoCompleteAction() {

        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this,android.R.layout.simple_list_item_1,stream);
        autoCompleteTextView.setAdapter(adapter);
        autoCompleteTextView.setThreshold(1);
    }

    private void setEvent() {

        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this,android.R.layout.select_dialog_singlechoice,country);
        spinner.setAdapter(adapter);
        Log.d("Country",(String) spinner.getSelectedItem());

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
               if(position != 0)
                    Toast.makeText(getApplicationContext(),country[position],Toast.LENGTH_LONG).show();
               else
                   onNothingSelected(parent);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(getApplicationContext(),"Please select your country",Toast.LENGTH_LONG).show();
            }
        });
    }
}
