package com.example.nshwe.uicomponents;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class DateNTimePickerActivity extends AppCompatActivity {

    EditText date_et,time_et;
    GregorianCalendar calendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_date_ntime_picker);

        date_et = findViewById(R.id.date);
        time_et = findViewById(R.id.time);

        date_et.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setDate();
            }
        });
        time_et.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTime();
            }
        });
    }

    private void setTime() {

        calendar = new GregorianCalendar();
        int hr = calendar.get(Calendar.HOUR);
        int min = calendar.get(Calendar.MINUTE);

       /* time_et.setOnClickListener((v) -> {

        });
*/
        TimePickerDialog dialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int i, int i1) {//i -> hour and i1 -> minute

                StringBuilder s = new StringBuilder();
                if(i == 12){
                    if (i1 < 10)
                        s.append(i+":0" + i1);
                    else
                        s.append(i+":"+i1);
                    time_et.setText(s + " " + "PM");
                }
                else if(i > 12){
                    i = i - 12;
                    if(i/10 == 0) {
                        s.append("0"+i);
                        if (i1 < 10)
                            s.append(":0" + i1);
                        else
                            s.append(":"+i1);
                        time_et.setText(s + " " + "PM");
                    }
                }
                else {
                    if(i == 0)
                        s.append("0"+i);
                    else if(i < 10)
                        s.append("0"+i);
                    else
                        s.append(i);
                    if(i1<10) {
                        s.append(":0" + i1);
                        time_et.setText(s + " " + "AM");
                    } else
                        time_et.setText(s +":"+i1 + " " + "AM");
                }
            }
        },hr,min,false);
        dialog.show();
    }

    private void setDate() {

        calendar = new GregorianCalendar();

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int date = calendar.get(Calendar.DATE);

        Log.d("Date",date+"/"+(month+1)+"/"+year);

        DatePickerDialog dialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                date_et.setText(dayOfMonth+"/"+(month+1)+"/"+year);
                date_et.setEnabled(false);
            }
        },year,month,date);
        dialog.show();
    }
}
