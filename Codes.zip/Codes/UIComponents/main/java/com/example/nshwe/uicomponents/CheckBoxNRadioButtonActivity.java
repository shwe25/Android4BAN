package com.example.nshwe.uicomponents;

import android.content.DialogInterface;
import android.content.res.Resources;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class CheckBoxNRadioButtonActivity extends AppCompatActivity {

    private RadioGroup radioGroup;
    private RadioButton radioButton;
    private CheckBox java, j2ee, android, sql;
    private Button fee_details;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_box_nradio_button);

        java = findViewById(R.id.checkBox_java);
        j2ee = findViewById(R.id.checkBox_j2ee);
        android = findViewById(R.id.checkBox_android);
        sql = findViewById(R.id.checkBox_sql);
        radioGroup = findViewById(R.id.radioGroup);

        fee_details = findViewById(R.id.button);

        fee_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAction();
            }
        });
    }

    private void setAction() {

        int id = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(id);

        int total_fee = 0;
        StringBuilder builder = new StringBuilder("Details");
        Resources res = getResources();
        if (java.isChecked()) {
            builder.append("\nJava - Rs." + res.getInteger(R.integer.java_fee));
            total_fee += res.getInteger(R.integer.java_fee);
        }
        if (j2ee.isChecked()) {
            builder.append("\nJ2ee - Rs." + res.getInteger(R.integer.j2ee_fee));
            total_fee += res.getInteger(R.integer.j2ee_fee);
        }
        if (android.isChecked()) {
            builder.append("\nAndroid - Rs." + res.getInteger(R.integer.android_fee));
            total_fee += res.getInteger(R.integer.android_fee);
        }
        if (sql.isChecked()) {
            builder.append("\nSql - Rs." + res.getInteger(R.integer.sql_fee));
            total_fee += res.getInteger(R.integer.sql_fee);
        }
        if (total_fee > 0) {
            builder.append("\n----------------------");
            builder.append("\nTotal fee - Rs." + total_fee);
            if(radioButton == null)
                Toast.makeText(this,"Choose Some display mode",Toast.LENGTH_SHORT).show();
            else {
                if (radioButton.getText().equals("Toast"))
                    dispToast(builder.toString());
                else
                    dispAlert(builder.toString());
            }
        }else {
            Toast.makeText(this,"Choose Some Courses",Toast.LENGTH_SHORT).show();
        }
    }

    private void dispAlert(String msg){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(this)
                .setTitle("Fee Details For Selected Courses")
                .setMessage(msg)
                .setCancelable(false)
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                })
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        CheckBoxNRadioButtonActivity.this.finish();
                    }
                });
        AlertDialog dialog = builder1.create();
        dialog.show();
    }

    private void dispToast(String msg){
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
