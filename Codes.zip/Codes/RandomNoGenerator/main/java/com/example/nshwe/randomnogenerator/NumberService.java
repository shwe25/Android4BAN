package com.example.nshwe.randomnogenerator;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.util.Random;

public class NumberService extends Service {

    private Random random = new Random();
    public final NumberBinder numberBinder = new NumberBinder();

    class NumberBinder extends Binder{
        public NumberService getNumberService(){
            return NumberService.this;
        }
    }
    @Override
    public IBinder onBind(Intent intent) {
        Log.d("NumberService","Service Started");
        return numberBinder;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("NumberService","Service Destroyed");
    }

    public int generateRandomNo(){
        return random.nextInt(1000);
    }
}
