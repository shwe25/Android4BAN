package com.example.nshwe.sharedpreferrencesapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText userId,password;
    private Button signin,reset;
    private CheckBox rememberMe;

    String user, pswd;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userId = findViewById(R.id.userId);
        password = findViewById(R.id.pswd);
        signin = findViewById(R.id.signin);
        reset = findViewById(R.id.reset);
        rememberMe = findViewById(R.id.rememberMe);

        sharedPreferences = getSharedPreferences("MyLoginData", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user = userId.getText().toString();
                pswd = password.getText().toString();
                validation();
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reset();
            }
        });
        directLogin();
    }

    private void reset() {
        userId.setText("");
        password.setText("");
        rememberMe.setChecked(false);
    }

    private void directLogin() {
        if(sharedPreferences.getBoolean("Checked",false))
            nextActivity();
    }

    private void validation() {
        if(user.equals("iam@iam.com") && pswd.equals("iamiam")) {
            if(rememberMe.isChecked())
                saveLoginRecords();
            nextActivity();
        }
        else
            Toast.makeText(this,"Invalid Credentials",Toast.LENGTH_SHORT).show();
    }

    private void nextActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }
    private void saveLoginRecords() {
            editor.putBoolean("Checked",true);
            editor.putString("user",user);
            editor.putString("pswd",pswd);
            editor.commit();

            Toast.makeText(this,"Data Saved Successfully",Toast.LENGTH_SHORT).show();
    }


}
