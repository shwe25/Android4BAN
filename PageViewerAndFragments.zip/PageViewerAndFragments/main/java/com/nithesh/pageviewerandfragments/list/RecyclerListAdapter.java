package com.nithesh.pageviewerandfragments.list;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.nithesh.pageviewerandfragments.R;

import java.util.List;

public class RecyclerListAdapter extends RecyclerView.Adapter<RecyclerListAdapter.MyViewHolder> {

    private Dialog dialog;
    private List<ListContent> contents;
    private Context context;

    public RecyclerListAdapter(List<ListContent> contents, Context context) {
        this.contents = contents;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.my_list_content,parent,false);

        final MyViewHolder viewHolder = new MyViewHolder(view);
    
        dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_content);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        viewHolder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView d_name = dialog.findViewById(R.id.dialog_name);
                TextView d_number = dialog.findViewById(R.id.dialog_number);
                ImageView d_img = dialog.findViewById(R.id.dialog_img);

                d_name.setText(contents.get(viewHolder.getAdapterPosition()).getName());
                d_number.setText(contents.get(viewHolder.getAdapterPosition()).getNumber());
                d_img.setImageResource(contents.get(viewHolder.getAdapterPosition()).getImage());
                dialog.show();
            }
        });

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        holder.name.setText(contents.get(position).getName());
        holder.number.setText(contents.get(position).getNumber());
        holder.imageView.setImageResource(contents.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return contents.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        private LinearLayout linearLayout;
        private ImageView imageView;
        TextView name,number;
        public MyViewHolder(View itemView) {
            super(itemView);

            linearLayout = itemView.findViewById(R.id.list_layout);
            imageView = itemView.findViewById(R.id.list_img);
            name = itemView.findViewById(R.id.list_name_tv);
            number = itemView.findViewById(R.id.list_number_tv);

        }
    }
}
