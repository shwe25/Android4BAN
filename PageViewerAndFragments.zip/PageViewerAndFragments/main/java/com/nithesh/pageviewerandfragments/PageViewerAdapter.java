package com.nithesh.pageviewerandfragments;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class PageViewerAdapter extends FragmentStatePagerAdapter {

    private final List<Fragment> LIST_FRAGMENT = new ArrayList<>();
    private final List<String> LIST_TITLE = new ArrayList<>();

    public PageViewerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return LIST_FRAGMENT.get(position);
    }

    @Override
    public int getCount() {
        return LIST_TITLE.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return LIST_TITLE.get(position);
    }

    public void addItems(Fragment fragment, String title){
        LIST_FRAGMENT.add(fragment);
        LIST_TITLE.add(title);
    }
}
