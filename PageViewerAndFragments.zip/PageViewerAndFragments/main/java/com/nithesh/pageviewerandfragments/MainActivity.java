package com.nithesh.pageviewerandfragments;

import android.support.design.widget.TabLayout;
import android.support.v4.app.ListFragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.nithesh.pageviewerandfragments.grid.MyGridFragment;
import com.nithesh.pageviewerandfragments.list.MyListFragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabLayout tabLayout = findViewById(R.id.tablayout);
        ViewPager viewPager = findViewById(R.id.viewPager);

        PageViewerAdapter viewerAdapter = new PageViewerAdapter(getSupportFragmentManager());

        viewerAdapter.addItems(new MyListFragment(),"");
        viewerAdapter.addItems(new MyGridFragment(),"");

        viewPager.setAdapter(viewerAdapter);

        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_list);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_grid);
    }
}