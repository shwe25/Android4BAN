package com.example.nshwe.fragmentwithpageviewer;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * Created by nshwe on 19-03-2018.
 */

public class RecyclerviewListAdapter extends RecyclerView.Adapter<RecyclerviewListAdapter.MyViewHolder> {

    private List<ContactDTO> data;
    private Context context;
    private Dialog dialog;

    public RecyclerviewListAdapter(List<ContactDTO> data, Context context) {
        this.data = data;
        this.context = context;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_content, parent, false);
        final MyViewHolder viewHolder = new MyViewHolder(view);
        dialog = new Dialog(context);
        dialog.setContentView(R.layout.dialog_contact);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        viewHolder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView d_name = dialog.findViewById(R.id.dialog_name);
                TextView d_phone = dialog.findViewById(R.id.dialog_phone);
                ImageView d_img = dialog.findViewById(R.id.dialog_img);

                Button call = dialog.findViewById(R.id.dialog_btn_call);
                Button msg = dialog.findViewById(R.id.dialog_btn_msg);

                String phoneNo = viewHolder.number.getText().toString();
                //to make call
                call.setOnClickListener((view1) -> {

                    if (!TextUtils.isEmpty(phoneNo)) {
                        String dial = "tel:" + phoneNo;
                        //context.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse(dial)));
                        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            // TODO: Consider calling
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            return;
                        }
                        context.startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
                    }
                });

                msg.setOnClickListener((view2) ->{
                    if(!TextUtils.isEmpty(phoneNo)) {
                        Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phoneNo));
                        context.startActivity(smsIntent);
                    }
                });

                d_name.setText(data.get(viewHolder.getAdapterPosition()).getName());
                d_phone.setText(data.get(viewHolder.getAdapterPosition()).getNumber());
                d_img.setImageResource(data.get(viewHolder.getAdapterPosition()).getImg());
                //Toast.makeText(context,"Test Check"+String.valueOf(viewHolder.getAdapterPosition()),Toast.LENGTH_LONG).show();
                dialog.show();
            }
        });

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.name.setText(data.get(position).getName());
        holder.number.setText(data.get(position).getNumber());
        holder.imageView.setImageResource(data.get(position).getImg());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        private LinearLayout linearLayout;
        private ImageView imageView;
        private TextView name,number;

        public MyViewHolder(View itemView) {
            super(itemView);
            linearLayout = itemView.findViewById(R.id.linearlayout);
            imageView = itemView.findViewById(R.id.item_img);
            name = itemView.findViewById(R.id.name_it);
            number = itemView.findViewById(R.id.num_it);

        }
    }
}
