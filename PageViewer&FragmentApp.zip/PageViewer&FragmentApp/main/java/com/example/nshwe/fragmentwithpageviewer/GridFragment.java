package com.example.nshwe.fragmentwithpageviewer;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class GridFragment extends Fragment implements RecyclerviewGridAdapter.ItemListener{

    View view;
    private RecyclerView recyclerView;
    private List<DataModel> datas;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_grid,container,false);

        recyclerView = view.findViewById(R.id.grid_recyclerview);
        RecyclerviewGridAdapter adapter = new RecyclerviewGridAdapter(datas,getContext(),this);
        recyclerView.setAdapter(adapter);

        AutoFixGridLayoutManager layoutManager = new AutoFixGridLayoutManager(getContext(),300);
        recyclerView.setLayoutManager(layoutManager);
        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        datas = new ArrayList<>();
        datas.add(new DataModel("Image 1",R.drawable.battle,"#09a9ff"));
        datas.add(new DataModel("Image 2",R.drawable.beer,"#3e51b1"));
        datas.add(new DataModel("Image 3",R.drawable.ferrari,"#673bb7"));
        datas.add(new DataModel("Image 4",R.drawable.jetpack_joyride,"#4baa50"));
        datas.add(new DataModel("Image 5",R.drawable.terraria,"#f94336"));
        datas.add(new DataModel("Image 6",R.drawable.three_d,"#0a9b88"));
        datas.add(new DataModel("Image 7",R.drawable.battle,"#09a9ff"));
        datas.add(new DataModel("Image 8",R.drawable.beer,"#3e51b1"));
        datas.add(new DataModel("Image 9",R.drawable.ferrari,"#673bb7"));
        datas.add(new DataModel("Image 10",R.drawable.jetpack_joyride,"#4baa50"));
        datas.add(new DataModel("Image 11",R.drawable.terraria,"#f94336"));
        datas.add(new DataModel("Image 12",R.drawable.three_d,"#0a9b88"));
    }

    @Override
    public void onItemClick(DataModel item) {
        Toast.makeText(getContext(),item.text+" is clicked",Toast.LENGTH_LONG).show();
    }
}
