package com.example.nshwe.fragmentwithpageviewer;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.List;

/**
 * Created by nshwe on 20-03-2018.
 */

public class RecyclerviewGridAdapter extends RecyclerView.Adapter<RecyclerviewGridAdapter.MyGridViewHolder> {

    private List<DataModel> datas;
    private Context context;
    public ItemListener itemListener;

    public RecyclerviewGridAdapter(List<DataModel> datas, Context context, ItemListener itemListener) {
        this.datas = datas;
        this.context = context;
        this.itemListener = itemListener;
    }
    @Override
    public MyGridViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.grid_content,parent,false);
        return new MyGridViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyGridViewHolder holder, int position) {
        holder.setData(datas.get(position));
    }

    @Override
    public int getItemCount() {
        return datas.size();
    }

    public class MyGridViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView textView;
        public ImageView imageView;
        public RelativeLayout relativeLayout;
        DataModel item;

        public MyGridViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);
            textView = itemView.findViewById(R.id.grid_text_view);
            imageView = itemView.findViewById(R.id.grid_img_view);
            relativeLayout = itemView.findViewById(R.id.grid_relativelayout);
        }
        @Override
        public void onClick(View v) {
            if(itemListener != null){
                itemListener.onItemClick(item);
            }
        }
        public void setData(DataModel item){
            this.item = item;
            textView.setText(item.text);
            imageView.setImageResource(item.img);
            relativeLayout.setBackgroundColor(Color.parseColor(item.color));
        }

    }
    public interface ItemListener {
        void onItemClick(DataModel item);
    }
}
