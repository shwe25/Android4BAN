package com.example.nshwe.fragmentwithpageviewer;

/**
 * Created by nshwe on 20-03-2018.
 */

public class DataModel {

    public String text;
    public int img;
    public String color;

    public DataModel(String text, int img, String color) {
        this.text = text;
        this.img = img;
        this.color = color;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
}
