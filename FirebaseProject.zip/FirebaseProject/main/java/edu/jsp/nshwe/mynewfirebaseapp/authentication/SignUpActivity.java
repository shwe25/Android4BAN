package edu.jsp.nshwe.mynewfirebaseapp.authentication;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

import edu.jsp.nshwe.mynewfirebaseapp.MainActivity;
import edu.jsp.nshwe.mynewfirebaseapp.R;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText email,password,confirmPswd;
    private Button signup;
    private TextView signin;
    private ProgressBar progressBar;

    private String mailId,pswd,confirm_pswd;

    private FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        email = findViewById(R.id.signup_email);
        password = findViewById(R.id.signup_pswd);
        confirmPswd = findViewById(R.id.signup_confirm_pswd);
        signup = findViewById(R.id.signup_btn);
        signin = findViewById(R.id.signup_login_btn);
        progressBar = findViewById(R.id.signup_progressbar);

        firebaseAuth = FirebaseAuth.getInstance();

        signin.setOnClickListener(this);
        signup.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.signup_btn:
                signUpUser();
                break;
            case R.id.signup_login_btn:
                Intent intent = new Intent(this,LoginActivity.class);
                startActivity(intent);
                finish();
        }
    }

    private void signUpUser() {
        if(isValidate()){
            progressBar.setVisibility(View.VISIBLE);

            firebaseAuth.createUserWithEmailAndPassword(mailId,pswd)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            progressBar.setVisibility(View.GONE);
                            if(task.isSuccessful()){
                                Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
                                startActivity(intent);
                                finish();
                            }else {
                                if(task.getException() instanceof FirebaseAuthUserCollisionException)
                                    Toast.makeText(getApplicationContext(),"You are already registered",Toast.LENGTH_SHORT).show();
                                else
                                    Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_LONG).show();
                            }
                        }
                    });
        }
        else
            return;
    }

    private boolean isValidate() {
        mailId = email.getText().toString();
        pswd = password.getText().toString();
        confirm_pswd = confirmPswd.getText().toString();

        if(mailId.isEmpty()){
            email.setError("Email Id is mandatory");
            email.requestFocus();
            return false;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(mailId).matches()){
            email.setError("Please enter a valid email id");
            email.requestFocus();
            return false;
        }
        if(pswd.isEmpty()){
            password.setError("Password is mandatory");
            password.requestFocus();
            return false;
        }
        if(pswd.length() < 6){
            password.setError("Minimum length of password should be 6");
            password.requestFocus();
            return false;
        }
        if(!confirm_pswd.equals(pswd)){
            confirmPswd.setError("Password should be matched");
            confirmPswd.requestFocus();
            return false;
        }
        return true;
    }


}
