package edu.jsp.nshwe.mynewfirebaseapp.authentication;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import edu.jsp.nshwe.mynewfirebaseapp.MainActivity;
import edu.jsp.nshwe.mynewfirebaseapp.R;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    private EditText email,password;
    private Button signin;
    private TextView signup;
    private ProgressBar progressBar;

    private String mailId,pswd;

    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email = findViewById(R.id.login_email);
        password = findViewById(R.id.login_pswd);
        signin = findViewById(R.id.login_btn);
        signup = findViewById(R.id.login_signup);
        progressBar = findViewById(R.id.login_progressbar);

        firebaseAuth = FirebaseAuth.getInstance();

        signup.setOnClickListener(this);
        signin.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.login_btn:
                loginUser();
                break;
            case R.id.login_signup:
                startActivity(new Intent(this,SignUpActivity.class));
                finish();
        }
    }

    private void loginUser() {
        if(isValidated()){
            progressBar.setVisibility(View.VISIBLE);

            firebaseAuth.signInWithEmailAndPassword(mailId,pswd)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            progressBar.setVisibility(View.GONE);
                            if(task.isSuccessful()){
                                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            }else
                                Toast.makeText(getApplicationContext(),task.getException().getMessage(),Toast.LENGTH_LONG).show();
                        }
                    });
        }
        else
            return;
    }

    public boolean isValidated() {
        mailId = email.getText().toString();
        pswd = password.getText().toString();

        if(mailId.isEmpty()){
            email.setError("Email Id is mandatory");
            email.requestFocus();
            return false;
        }
        if(!Patterns.EMAIL_ADDRESS.matcher(mailId).matches()){
            email.setError("Please enter a valid email id");
            email.requestFocus();
            return false;
        }
        if(pswd.isEmpty()){
            password.setError("Password is mandatory");
            password.requestFocus();
            return false;
        }
        if(pswd.length() < 6){
            password.setError("Minimum length of password should be 6");
            password.requestFocus();
            return false;
        }
        return true;
    }
}
